<?php

header('Content-Type: application/json; charset=utf-8');
date_default_timezone_set('America/Sao_Paulo');
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Método não permitido']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$time1 = isset($input['time1']) ? trim($input['time1']) : '';
$time2 = isset($input['time2']) ? trim($input['time2']) : '';
$tipo = isset($input['tipo']) ? trim($input['tipo']) : 'gols';
$limite = isset($input['limite']) ? intval($input['limite']) : 5;

error_log("📊 Histórico: time1='$time1', time2='$time2', tipo='$tipo', limite=$limite");

if ($limite < 1 || $limite > 50) $limite = 5;
if (empty($time1) || empty($time2)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Times inválidos']);
    exit;
}

if ($conexao->connect_error) {
    http_response_code(500);
    error_log("❌ Erro de conexão: " . $conexao->connect_error);
    echo json_encode(['success' => false, 'error' => 'Erro de conexão']);
    exit;
}

$conexao->set_charset("utf8mb4");

try {
    // ✅ BUSCAR ÚLTIMOS N JOGOS DO TIME 1
    $sql1 = "SELECT 
                id,
                resultado,
                data_criacao,
                time_1,
                time_2,
                placar_1,
                placar_2,
                tipo_aposta
            FROM bote 
            WHERE (LOWER(time_1) = LOWER(?) OR LOWER(time_2) = LOWER(?))
            AND LOWER(tipo_aposta) LIKE LOWER(CONCAT('%', ?, '%'))
            ORDER BY data_criacao DESC
            LIMIT ?";

    $stmt1 = $conexao->prepare($sql1);
    if (!$stmt1) {
        throw new Exception("Erro SQL1: " . $conexao->error);
    }
    
    $stmt1->bind_param('sssi', $time1, $time1, $tipo, $limite);
    $stmt1->execute();
    $resultado1 = $stmt1->get_result();
    $historico_time1 = [];

    while ($row = $resultado1->fetch_assoc()) {
        // ✅ Identificar adversário
        $adversario = strtolower($row['time_1']) === strtolower($time1) ? $row['time_2'] : $row['time_1'];
        
        $historico_time1[] = [
            'id' => $row['id'],
            'resultado' => $row['resultado'],
            'data_criacao' => $row['data_criacao'],
            'time_1' => $row['time_1'],
            'time_2' => $row['time_2'],
            'placar_1' => $row['placar_1'],
            'placar_2' => $row['placar_2'],
            'adversario' => $adversario,
            'tipo_aposta' => $row['tipo_aposta']
        ];
    }
    $stmt1->close();

    error_log("✅ Time 1 ($time1): " . count($historico_time1) . " jogos encontrados");

    // ✅ BUSCAR ÚLTIMOS N JOGOS DO TIME 2
    $sql2 = "SELECT 
                id,
                resultado,
                data_criacao,
                time_1,
                time_2,
                placar_1,
                placar_2,
                tipo_aposta
            FROM bote
            WHERE (LOWER(time_1) = LOWER(?) OR LOWER(time_2) = LOWER(?))
            AND LOWER(tipo_aposta) LIKE LOWER(CONCAT('%', ?, '%'))
            ORDER BY data_criacao DESC
            LIMIT ?";

    $stmt2 = $conexao->prepare($sql2);
    if (!$stmt2) {
        throw new Exception("Erro SQL2: " . $conexao->error);
    }
    
    $stmt2->bind_param('sssi', $time2, $time2, $tipo, $limite);
    $stmt2->execute();
    $resultado2 = $stmt2->get_result();
    $historico_time2 = [];

    while ($row = $resultado2->fetch_assoc()) {
        // ✅ Identificar adversário
        $adversario = strtolower($row['time_1']) === strtolower($time2) ? $row['time_2'] : $row['time_1'];
        
        $historico_time2[] = [
            'id' => $row['id'],
            'resultado' => $row['resultado'],
            'data_criacao' => $row['data_criacao'],
            'time_1' => $row['time_1'],
            'time_2' => $row['time_2'],
            'placar_1' => $row['placar_1'],
            'placar_2' => $row['placar_2'],
            'adversario' => $adversario,
            'tipo_aposta' => $row['tipo_aposta']
        ];
    }
    $stmt2->close();

    error_log("✅ Time 2 ($time2): " . count($historico_time2) . " jogos encontrados");

    // ✅ ENCONTRAR CONFRONTOS DIRETOS (games onde os dois se enfrentaram)
    $confrontos_diretos = [];
    foreach ($historico_time1 as $jogo1) {
        foreach ($historico_time2 as $jogo2) {
            // Verificar se é o mesmo jogo (mesma data e times opostos)
            if ($jogo1['data_criacao'] === $jogo2['data_criacao'] &&
                strtolower($jogo1['time_1']) === strtolower($jogo2['time_1']) &&
                strtolower($jogo1['time_2']) === strtolower($jogo2['time_2'])) {
                $confrontos_diretos[] = $jogo1['id'];
            }
        }
    }

    error_log("⚔️ Confrontos diretos encontrados: " . count($confrontos_diretos));

    // ✅ RETORNAR COM MARCAÇÃO DE CONFRONTOS DIRETOS
    http_response_code(200);
    echo json_encode([
        'success' => true,
        'time1_historico' => $historico_time1,
        'time2_historico' => $historico_time2,
        'confrontos_diretos' => $confrontos_diretos,
        'total_time1' => count($historico_time1),
        'total_time2' => count($historico_time2),
        'tipo' => $tipo
    ]);

} catch (Exception $e) {
    http_response_code(500);
    error_log("❌ Exceção: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Erro: ' . $e->getMessage()
    ]);
}

$conexao->close();
?>
